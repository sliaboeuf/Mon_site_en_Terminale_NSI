import binary_IO

def completeDernierOctet(texteCompresse):
    """
    Rôle: cette fonction retourne la chaine de caractères passée en
    paramètre complétée par un '1' et des '0' afin d'obtenir un
    nombre entier d'octets.

    Exemples:
        completeDernierOctet('') -> 10000000
        completeDernierOctet('010') -> 01010000
        completeDernierOctet('1010111') -> 10101111

    Parameters
    ----------
    texteCompresse: (str) chaine de caractères contenant une suite de '0' et
    de '1'.

    Returns
    -------
    (str) chaine de caractères '0' ou '1' de longueur multiple de 8.
    """

    nbBits = len(texteCompresse)
    bitsRestant = nbBits % 8
    if bitsRestant != 0:
        return texteCompresse + '1' + '0' * (7 - bitsRestant)
    else:
        return texteCompresse + '10000000'


def uncompleteDernierOctet(chaineOctets):
    """
    Rôle: cette fonction supprime les bits de complétion du dernier octet.

    Exemples:
        uncompleteDernierOctet('01000000') -> '0'
        uncompleteDernierOctet('01010100') -> '01010'

    Parameters
    ----------
    chaineOctets: (str) une chaîne de bits avec un nombre entier d'octets.

    Returns
    -------
    (str) une chaîne de bits débarrassée du bit 1 le plus à droite ainsi que
    des bits à '0'.
    """

    return chaineOctets[:chaineOctets.rindex('1')]  # Renvoie la chaine de bits (texte compressé) sans les bits qui ont permis de compléter le dernier octet


def sauveDicoOccurrences(nomFichier, dicoOcc):
    """
    Rôle: cette fonction sauvegarde le dictionnaire d'occurrences (%
    d'apparition) dans un fichier avec extension occ.

    Parameters
    ----------
    dicoOcc: (dict) dictionnaire avec le pourcentage d'apparition des
    différents symboles (dictionnaire d'occurences).
    nomFichier: (str) nom du fichier de sauvegarde du dictionnaire.
    """

    with open(nomFichier, 'w') as writer:
        for symb in dicoOcc:
            writer.write(f'{symb}:{dicoOcc[symb]}\n')


def lireFichierDicoOcc(nomFichierOcc):
    """
    Rôle: cette fonction lit le fichier contenant le dictionnaire
    d'occurrences, reconstitue le dictionnaire et le renvoie.

    Parameters
    ----------
    nomFichierOcc: (str) nom du fichier contenant le dictionnaire
    d'occurrences (pourcentages d'apparition).

    Returns
    -------
    (dict) le dictionnaire d'occurrences.
    """

    dicoOcc = dict()
    with open(nomFichierOcc, 'r') as contenu:
        for ligne in contenu:
            elts = ligne.rstrip().split(':')
            dicoOcc[int(elts[0])] = int(elts[1])
    return dicoOcc


def litFichierBinaire(nomFichierSource):
    """
    Rôle: cette fonction lit l'ensemble des octets d'un fichier.

    Parameters
    ----------
    fichierSource: (str) nom du fichier avec extension.

    Returns
    -------
    (list) une liste d'octets.
    """

    contenu = binary_IO.Reader(nomFichierSource)
    listeOctets = contenu.get_bytes()
    contenu.close()
    return listeOctets


def ecritFichierBinaire(nomFichier, listeOctets):
    """
    Rôle: cette fonction créé et écrit un fichier en binaire sous le nom
    'nomFichier'.

    Parameters
    ----------
    nomFichier: (str) Nom du fichier destination avec extension.
    listeOctets: (list) liste d'octets à écrire dans le fichier
    """

    writer = binary_IO.Writer(nomFichier)
    writer.write_bytes(listeOctets)
    writer.close()










