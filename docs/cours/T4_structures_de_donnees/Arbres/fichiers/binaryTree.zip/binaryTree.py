
class Arbre :

    def __init__(self, valeur = None, G = None, D = None):
        self.valeur = valeur
        self.G = G
        self.D = D

    def affichage(self, niveau = 0, c = 132):
        if self.D:
            self.D.affichage(niveau + 1,47)
        if self.valeur :
            if self.valeur[0] == '':
                print(f"{' ' * 4 * niveau}{chr(c)}{self.valeur[1]}")
            else :
                print(f"{' ' * 4 * niveau}{chr(c)}{self.valeur}")
        if self.G:
            self.G.affichage(niveau + 1,92)

    def estVide(self):
        return not self.valeur

    def cle(self):
        return self.valeur

    def sousArbreGauche(self):
        if self.G :
            return self.G
        return Arbre()

    def sousArbreDroit(self):
        if self.D :
            return self.D
        return Arbre()

    def taille(self):
        if self.estVide() :
            return 0

        gauche, droit = self.sousArbreGauche(), self.sousArbreDroit()
        return 1 + gauche.taille() + droit.taille()

    def hauteur(self):
        if self.estVide() :
            return -1

        gauche, droit = self.sousArbreGauche(), self.sousArbreDroit()
        return 1 + max(gauche.hauteur(), droit.hauteur())

    def estFeuille(self):
        if self.estVide() :
            return False

        gauche, droit = self.sousArbreGauche(), self.sousArbreDroit()
        return gauche.estVide() and droit.estVide()

    def nbFeuilles(self):
        if self.estVide():
            return 0

        if self.estFeuille():
            return 1

        gauche, droit = self.sousArbreGauche(), self.sousArbreDroit()
        return gauche.nbFeuilles() + droit.nbFeuilles()

    def parcoursInfixe(self):
        if self.estVide():
            return

        gauche, droit = self.sousArbreGauche(), self.sousArbreDroit()
        gauche.parcoursInfixe()
        print(self.valeur, end = " ")
        droit.parcoursInfixe()

    def listeParcoursInfixe(self, L = []):
        if self.estVide():
            return

        gauche, droit = self.sousArbreGauche(), self.sousArbreDroit()
        gauche.listeParcoursInfixe(L)
        L.append(self.valeur)
        droit.listeParcoursInfixe(L)
        return L

    def parcoursLargeur(self) :
        f = File()
        f.enfiler(self)

        while not f.estVide():
            n = f.defiler()
            fg, fd = n.sousArbreGauche(), n.sousArbreDroit()
            if not fg.estVide():
                f.enfiler(fg)
            if not fd.estVide():
                f.enfiler(fd)
            print(n.cle(), end = ' ') # on traite le noeud
        print('')

    def rechercherElement(self, e):
        assert self.estABR() == True, "L'arbre n'est pas un ABR"

        if self.estVide():
            return False
        if e == self.cle():
            return True
        gauche, droit = self.sousArbreGauche(), self.sousArbreDroit()
        if e < self.cle():
            if not gauche.estVide():
                return gauche.rechercherElement(e)
            return False
        if e > self.cle():
            if not droit.estVide():
                return droit.rechercherElement(e)
            return False

    def insererElement(self, e) :
        assert self.estABR() == True, "L'arbre n'est pas un ABR"

        if self.estVide():
            self.valeur = e
        else :
            gauche, droit = self.sousArbreGauche(), self.sousArbreDroit()
            if e <= self.valeur:
                if not gauche.estVide():
                    gauche.insererElement(e)
                else :
                    self.G = Arbre(e)
            else :
                if not droit.estVide():
                    droit.insererElement(e)
                else :
                    self.D = Arbre(e)




